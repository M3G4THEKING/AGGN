from .ninjemail_manager import Ninjemail
