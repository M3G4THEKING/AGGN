(()=>{function o(e){postMessage({source:"nopecha",...e})}function l(e){o(e)}})();
