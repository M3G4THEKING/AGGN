import json
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def connect_to_existing_driver():
    with open('session.json', 'r') as f:
        session_data = json.load(f)

    session_id = session_data['sessionId']
    capabilities = session_data['capabilities']
    remote_url = session_data['remoteUrl']

    options = Options()
    for key, value in capabilities.items():
        print(key)
        options.set_capability(key, value)

    driver = webdriver.Remote(command_executor=remote_url, options=options)
    
    # Используем сохраненную сессию
    driver.session_id = session_id
    return driver


def test_fingerprint_application():
    driver = connect_to_existing_driver()
    driver.get('https://browserleaks.com/canvas')

    browser_user_agent = driver.execute_script("return navigator.userAgent;")
    print("User-Agent from Browser:", browser_user_agent)
    browser_user_platform = driver.execute_script("return navigator.platform;")
    print("Platform from Browser:", browser_user_platform)

    browser_logs = driver.get_log("browser")
    for log in browser_logs:
        print(log)

    driver.quit()

if __name__ == '__main__':
    test_fingerprint_application()
