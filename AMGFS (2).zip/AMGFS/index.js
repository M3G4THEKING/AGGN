const { plugin } = require('selenium-with-fingerprints');
const fs = require('fs');


async function getRandomProxy(filePath) {
    const data = fs.readFileSync(filePath, 'utf-8');
    const proxies = data.split('\n').map(proxy => proxy.trim()).filter(proxy => proxy);
    
    if (proxies.length === 0) {
        throw new Error('No proxies found in the provided file.');
    }

    const randomIndex = Math.floor(Math.random() * proxies.length);
    const selectedProxy = proxies[randomIndex];

    // Добавляем протокол SOCKS5
    return `socks5://${selectedProxy}`;
}


(async () => {
  // Чтение отпечатка из файла
  const fingerprint = await plugin.fetch('7sEafeeK98qtzPBd4G2DsJzvUDsiQVdwI8nIeSrT2Jargb4f5Iv1nFjM13W6KLCl')
  console.log('fetch fingerprint done');

  const proxy = await getRandomProxy('proxies.txt')
  console.log(proxy)

  // Применение отпечатка
  plugin.useProxy(proxy).useFingerprint(fingerprint);


  // Запуск браузера
  const driver = await plugin.launch();

  driver.get('https://2ip.io/ua/')

})();
